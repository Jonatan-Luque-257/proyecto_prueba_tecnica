IMPORTANTE: debe tener instalado "node"
npm install       para las dependencias
npx turbo run dev         para correr desde la raiz el front y back juntos
falta agregar o editar el .env utilizando el .env.example cambiandolo a .env simplemente

CHAT-GPT dice:
# Proyecto Prueba Técnica
  *incluir toda la explicacion de lo que hace

Este proyecto incluye:
- API REST construida con Node.js, Express y TypeORM.
- Frontend simple con React y Next.js (Client Side Rendering).
- Base de datos MySQL.

## Cómo ejecutar

### Backend
1. Ir a la carpeta `backend`
2. Instalar dependencias:
   ```bash
   npm install
   Configurar la base de datos en .env
   npm run dev corre frontend o backend por separados desde su respectiva carpeta

El frontend corre en http://localhost:3000 y el backend en http://localhost:3001.